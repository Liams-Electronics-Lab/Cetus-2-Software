PROG 0 ;程序0. 系统初始化, Data:220928, 注:无送丝检测, 水平校准每点一次,提高速度到2mm/s.
SET 16 0 ;PrinterStatus = SYSTEMERROR
SET 10 0   ;设定层号为0,CURLAYER_VAR
SET 11 0   ;设定层高为0,CURHEIGHT_VAR
SET 80 20 ; XY Dock position.
SET 81 10
SET 82 -240
SET 71 60
SET 72 60
M300 S4 P2000;打开蜂鸣器
OUT 0 1  ;打开数控系统电源
SET 20 0   ;关闭三个温控
SET 21 0
SET 22 0
SET 23 0   ;关闭所有喷头和送丝电机
DWELL 2000
M300 S1 P100000
M104 T0 B0 ;Reset Temperature bias.
M104 T1 B0
G92.9 X0 Y0 Z0 E0 B0 ;恢复坐标偏置为零
G92 Y0 Z-20  ;重置YZ轴位置为0,-15,以便初始化移动
JOG 10 Z20   ;Z向上移动15mm,为XY回零时不刮蹭模型.同时不干扰Y轴寻找霍尔限位
JOG 50 Y50 ;先移动50mm,保证Y轴在霍尔开关右侧.
G28 X5 Y7 F3000 ;X负向回零,返回5mm, Y反向回零,反回7mm,50mm/s
G28 X5 Y5 F300  ;低速再来一次5mm/s
G92 Y45   ;重置Y轴位置.
G0 X5 Y5 F3000 ;回零后,走到不碰触的位置,
G28 Z15 F600 ;Z反向回零, 回零后正向15mm,保证完全释放回零开关. 
G28 Z5 F180  ;低速重复3mm/s
G92 Z-295   ;重置Z轴位置.
TO 10 Z[V82]	;Dock Z pos
M300 S2 P10000
DWELL 1000
TO 50 X[V80] Y[V81] ;XY走到预设位置
SET 28 0
SET 16 1   ;PrinterStatus = PREPARED
SET 29 50000	;VAR_MAXDIFFLEN, 送丝检测长度,脉冲数.
M51 F49 V49 R	;从FlashVar49中读取检测标志位.
;SET 49 0x0300 ;检测材料1/2, modify by guoge 20211115
;CHECK_IN_POWERON 0x0010
;CHECK_IN_LIGHTON 0x0020
;CHECK_IN_MAT1  0x0100  检查材料1
;CHECK_IN_MAT2  0x0200  检查材料2
SET V98 0x020 ;应变位置检测.
;#define SYSTEM_FUNC_UPDATE2SERVER	0X0001		//REPORT PRINTER STATUS TO SERVER.add by guoge 20160308
;#define SYSTEM_FUNC_PREHEAT	 	0x0002
;#define SYSTEM_FUNC_SAFEMODE	 	0x0004
;#define SYSTEM_FUNC_WIDEHEATPULSE 	0x0008		//宽加热脉冲。add by guoge 20200213
;#define SYSTEM_FUNC_AUTOLIST 		0x0010		//自动换版连续打印。add by guoge 20210916
;#define SYSTEM_FUNC_STRAINPROBE	0x0020 		//应变片位置检测. add by guoge 20220105
;#define SYSTEM_FUNC_PLATRECHARGE	0x0040 		//自动换板 add by guoge 20220109
M300 S0
END

PROG 1 ;程序1, 系统重新初始化
DWELL 100
TO 100 X[V80] Y[V81]
SET 10 0   ;设定层号为0,CURLAYER_VAR
SET 11 0   ;设定层高为0,CURHEIGHT_VAR
SET 16 1   ;PrinterStatus = PREPARED
SET 28 0
DWELL 100
END

PROG 2 ;程序2,开始造型
G92.8   ;enable nozzle height offset.
G92.6   ;apply plat level calibration.
M104 T0 B0 ;Reset Temperature bias.
M104 T1 B0
M220 S100 ;Reset Speed Acc scale to 100%.
M221 E100 ;Reset Feed Scale to 100%.
SET 28 0 ;VAR_PRINTING=0,没有开始打印
SET 16 2 ;VAR_PRINTERSTATUS = RUNING
SET 23 1 ;打开喷头1,送丝1电机.
SET 20 1  ;打开温控1
SET 21 1  ;打开温控2
SET 22 1  ;打开成型室温控
SET 76 0 ;PRINT PERCENT
M300 S4 P1000 ;蜂鸣器每秒响4次,持续1000ms
WAIT V18 = 1 ;等待喷头1到达温度
M300 S4 P2000 ;打开蜂鸣器,持续2000ms
SET 28 1  ;VAR_PRINTING=1. 加到温度后开始正式打印
DWELL 5000 ;再等待5秒,
M300 S2 P2000

PROG 3 ;程序3, 用户停止造型
G92.7  ;停用喷头高度偏移
M300 S4 P2000;
;SET 28 0 	;VAR_PRINTING=0.
M1001		;print finish.
SET 16 1  ;VAR_PRINTERSTATUS = PREPARE, 2014/01/21修改。原来为USERSTOP(7)
SET 20 0  ;关闭温控1
SET 21 0  ;关闭温控2
SET 22 0  ;关闭温控成型室
SET 23 0   ;关闭所有喷头和送丝电机
JOG 20 Z50  ;Z向上走50mm.
TO 100 X[V80] Y[V81]  ;YZ go to dock position.
DWELL 100
END

PROG 4 ;程序4, 出错停止造型
G92.7 ;停用喷头高度偏移
;SET 28 0 	;VAR_PRINTING=0.
M1001		;print finish.
SET 20 0  ;关闭温控1
SET 21 0  ;关闭温控2
SET 22 0  ;关闭温控成型室
SET 23 0   ;关闭所有喷头和送丝电机
JOG 20 Z50  ;Z向上走50mm.
TO 100 X[V80] Y[V81]  ;YZ go to dock position.
M300 S8 P4000 ;打开蜂鸣器,4000ms 
END

PROG 5 ;程序5, 造型完成
JOG 1000 A-20	;回抽
JOG 150 X-5 Y-5 ;跳转
G92.7 ;停用喷头高度偏移
;SET 28 0 	;VAR_PRINTING=0.
M1001		;print finish.
SET 10 0
SET 11 0
SET 20 0  ;关闭温控1
SET 21 0  ;关闭温控2
SET 22 0  ;关闭温控成型室
SET 23 0  ;关闭所有喷头和送丝电机
DWELL 100
JOG 20 Z50  ;Z向上50mm
TO 100 X[V80] Y[V81]
M300 S2 P3000;打开蜂鸣器, 3000ms
SET 16 1 ;PrinterStatus = PREPARED
SET 76 0 ;PRINT PERCENT
;END

PROG 6 ;程序6, 关闭系统
G92.7 ;停用喷头高度偏移
;SET 28 0 	;VAR_PRINTING=0.
M1001		;print finish.
SET 20 0  ;关闭温控1
SET 21 0  ;关闭温控2
SET 22 0  ;关闭温控成型室
SET 23 0   ;关闭所有喷头和送丝电机
SET 16 0 ;VAR_PRINTERSTATUS = SYSTEMERROR
M300 S1 P10000
TO 20 Z0 ;go to dock position.
TO 50 X[V80] Y[V81]
M300 S4 P2000 ;打开蜂鸣器,循环响两声 
OUT 0 0     ;数控系统掉电
END

PROG 7 ;程序7, 初始化喷头
SET 20 1 ;打开温控1
SET 21 1
M300 S1 P1000
WAIT V18 = 1 ;等待系统变量18为1, 喷头1加热到温度
M300 S2 P100000;打开蜂鸣器 
;SET 23 1  ;打开喷头1.送丝1,关闭喷头2,送丝2
J150 A-50 ;主材料撤回-50长度 why??
DWELL 10
;SET 23 2  ;打开喷头2.送丝2,关闭喷头1,送丝1
JOG 50 B1500 ;副材料送进
JOG 150 B-50 ;副材料回抽一定距离
DWELL 10
;SET 23 1  ;打开喷头1.送丝1,关闭喷头2,送丝2
JOG 50 A1500
SET 20 0   ;关闭温控1
M300 S4 P1000;打开蜂鸣器 
END

PROG 8 ;程序8,喷头1吐丝
M300 S2 P1000
SET 20 300  ;打开温控1,最长300秒
SET 21 300  ;打开温控2,最长300秒
DWELL 1000
WAIT V18 = 1 ;等待系统变量18为1, 喷头1加热到温度
M300 S1 P100000;打开蜂鸣器 
;IF 23 = 2  ;如果喷头2打开状态,先撤出副材料
;JOG 150 A-350
;IFEND
;SET 23 1  ;打开喷头1.送丝1,关闭喷头2,送丝2
JOG 50 A2000
SET 20 0  ;关闭温控1
SET 21 0  ;关闭温控2
M300 S4 P1000;打开蜂鸣器
END

PROG 9 ;程序9,喷头2吐丝
M300 S2 P1000
SET 20 300  ;打开温控1,最长300秒
SET 21 300  ;打开温控2,最长300秒
DWELL 1000
WAIT V19 = 1 ;等待系统变量18为1, 喷头1加热到温度
M300 S1 P100000 ;打开蜂鸣器 
;IF 23 = 1  ;如果喷头1打开状态,先撤出主材料
;JOG 150 A-50
;IFEND
;SET 23 2  ;打开喷头2.送丝2,关闭喷头1,送丝1
JOG 50 B2000
SET 20 0  ;关闭温控1
SET 21 0  ;关闭温控2
M300 S4 P1000;打开蜂鸣器 
END

PROG 10 ;程序10,退出喷头1
M300 S2 P1000
SET 20 300  ;打开温控1,最长300秒
SET 21 300  ;打开温控2,最长300秒
;SET 23 1   ;打开喷头1.送丝1,关闭喷头2,送丝2
DWELL 1000
WAIT V18 = 1 ;等待系统变量18为1, 喷头1加热到温度
M300 S1 P1000 ;打开蜂鸣器 
SET 20 0  ;关闭温控1
SET 21 0  ;关闭温控2
JOG 50 A-500
JOG 200 A-1000
M300 S4 P1000 ;打开蜂鸣器 
END

PROG 11 ;程序11,退出喷头2
M300 S2 P1000
SET 20 300  ;打开温控1,最长300秒
SET 21 300  ;打开温控2,最长300秒
;SET 23 2   ;打开喷头2.送丝2,关闭喷头1,送丝1
DWELL 1000
WAIT V19 = 1 ;等待系统变量18为1, 喷头1加热到温度
M300 S1 P100000;打开蜂鸣器
SET 20 0  ;关闭温控1
SET 21 0  ;关闭温控2
JOG 50 B-500
JOG 200 B-1000
M300 S4 P1000 ;打开蜂鸣器 
END

PROG 12 ;程序12,切换到主喷头
JOG 150 B-340    ;现在的喷头撤回一点丝
DWELL 10
;SET 23 1   ;打开喷头1和送丝1
DWELL 10
JOG 150 A300 ;送进材料
JOG 70 A35

PROG 13 ;程序13,切换到副喷头
JOG 150 A-340    ;现在的喷头撤回一点丝
DWELL 10
;SET 23 2   ;打开喷头2和送丝2
DWELL 10
JOG 150 B300 ;送进材料
JOG 70 A35

PROG 14 ;程序14,走到停靠位置. PROG_GOTODOCK
M300 S2 P1000 ;打开蜂鸣器,响两声.
TO 50 X[V80] Y[V81] Z[V82] ;XY走到预设位置
END

PROG 19 ;Program 19, Nozzle height detect and Level compensation.
M300 S4 P100000
DEF G30 G0 Z{Z} F600,G0 X{X} Y{Y} F6000,G4 S2,G28 Z2 F300 P{P},G4 S2,G28 Z0.2 F120 P{P},G4 P200,SET V{V} V302
DEF G31 JOG 10 Z2,G0 X{X} Y{Y} F6000,G4 S1,G28 Z0.2 F120 P{P},G4 P200,SET V{V} V302
G30 X20 Y20 Z-270 P39 V261 ;执行自定义的G30命令,Z要设定初始高度.
M300 S2 P100000
G31 X20 Y107  P39 V262 ;第二点以后用G31命令.Z已有相对高高度.
G31 X20 Y193  P39 V263
G31 X20 Y280   P39 V264
G31 X100 Y280  P39 V268
G31 X100 Y193 P39 V267
G31 X100 Y107 P39 V266
G31 X100 Y20 P39 V265
G31 X180 Y20 P39 V269
G31 X180 Y107 P39 V270
G31 X180 Y193 P39 V271
G31 X180 Y280  P39 V272
M53 V251 F261 T272 G ;取261到272的最大值到V251,作为喷头高度.
SET V253 -1
M54 F251 T251 M253; 乘以-1,变换为正值. 
SET V250 211101
SET V252 0
M50 B10 V250 S3 ;Save Var250~252 to SDBlock10(SD_NOZZLEHEIGHT)
SET V260 211101 ;SD Block verify data for Shark,
M54 F261 T272 A251 M253 ; V261-272,计算校准值,加上最大值(正值了),然后乘以-1,变换符号为正值.
M50 B16 V260 S13 ;Save Var260~272 to SDBlock16(SD_ZCOMP, 13 = 4*3+1)
SET V253 211101
SET V254 3 ;ROW
SET V255 4 ;COL
SET V256 20 ;min position
SET V257 20
SET V258 180 ; max position
SET V259 280
M50 B8 V253 S7 ;Save Var253~259 to SDBlock8(SD_ZCOMP_DEF, 7 int)
M300 S1 P10000 ;beep
G0 X[V80] Y[V81] Z-270
DEF G30 ;删除G30定义.
DEF G31
M300 S0
END

PROG 1000
